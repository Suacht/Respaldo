// Variables

var page = require('movian/page');
var service = require('movian/service');
var settings = require('movian/settings');
var http = require('movian/http');
var string = require('native/string');
var popup = require('native/popup');
var store = require('movian/store');
var plugin = JSON.parse(Plugin.manifest);
var logo = Plugin.path + plugin.icon;

var favorites = store.create('favorites');
if (!favorites.list) {
  favorites.list = JSON.stringify([]);
}

function setPageHeader(page, title) {
  page.metadata.title = title;
  page.metadata.logo = logo;
  page.metadata.background = Plugin.path + "bg.png";
  page.metadata.icon = Plugin.path + plugin.icon;
  page.model.contents = 'grid';
  page.type = "directory";
  page.contents = "items";
  page.entries = 0;
  page.loading = true;
}

service.create(plugin.title, plugin.id + ":start", 'video', true, logo);

settings.globalSettings(plugin.id, plugin.title, logo, plugin.synopsis);
settings.createBool('disableMyFavorites', 'Ocultar tus Favoritos', false, function(v) {
  service.disableMyFavorites = v;
});

// Favoritos

function addOptionForAddingToMyFavorites(item, identifier, title, mediatype, icon) {
  item.addOptAction('Agrega \'' + title + '\' a Tus Favoritos', function() {
    var entry = JSON.stringify({
      identifier: identifier,
      title: title,
      mediatype: mediatype,
      icon: icon
    });
    favorites.list = JSON.stringify([entry].concat(eval(favorites.list)));
    popup.notify('\'' + title + '\' a sido Agregado a Tus Favoritos.', 2);
  });
}

// PROCESAR

function addMediaItem(page, media) {
  var decodedIdentifier = decodeURIComponent(media.identifier);
  var decodedTitle = decodeURIComponent(media.title);
  var decodedMediatype = decodeURIComponent(media.mediatype);
  var decodedIcon = "https://archive.org/services/img/" + decodedIdentifier;
  var item = page.appendItem("internetarchive:files:" + decodedIdentifier, "video", {
    title: decodedTitle,
    icon: decodedIcon,
    description: "Type: " + decodedMediatype
  });
  item.icon = decodedIcon;
  addOptionForAddingToMyFavorites(item, decodedIdentifier, decodedTitle, decodedMediatype, decodedIcon);
  page.entries++;
}

function addDiscoverSection(page) {
  var offset = 1;
  var count = 9;

  function loader() {
    if (!offset) return false;
    page.loading = true;

    var args = {
      q: 'mediatype:(movies OR audio)',
      fl: ["identifier", "title", "mediatype"],
      sort: ["downloads desc"],
      rows: count,
      page: offset,
      output: "json"
    };

    try {
      var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
        args: args
      }));
    } catch(err) {
      page.error('No se pudieron recuperar datos de Internet Archive.');
      return;
    }

    if (offset == 1) {
      page.appendItem("", "separator", {
        title: ''
      });
    }

    page.loading = false;
    for (var i in c.response.docs) {
      var item = c.response.docs[i];
      if (item.mediatype === 'movies' || item.mediatype === 'audio') {
        addMediaItem(page, item);
        if (page.entries >= count) return offset = false;
      }
    }

    offset++;
    return c.response.docs && c.response.docs.length > 0;
  }
  loader();
  page.paginator = loader;
  page.loading = false;
}

function browseItems(page, query, count) {
  var offset = 1;
  page.entries = 0;

  function loader() {
    if (!offset) return false;
    page.loading = true;

    var args = {
      q: query,
      fl: ["identifier", "title", "mediatype"],
      sort: ["downloads desc"],
      rows: count ? count : 50,
      page: offset,
      output: "json"
    };

    try {
      var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
        args: args
      }));
    } catch(err) {
      page.error('No se pudieron recuperar datos de Internet Archive.');
      return;
    }

    page.loading = false;
    if (offset == 1 && page.metadata && c.response.numFound)
      page.metadata.title = "Internet Archive";
    page.model.contents = 'grid';
    for (var i in c.response.docs) {
      var item = c.response.docs[i];
      if (item.mediatype === 'movies' || item.mediatype === 'audio') {
        addMediaItem(page, item);
        if (count && page.entries >= count) return offset = false;
      }
    }
    offset++;
    return c.response.docs && c.response.docs.length > 0;
  }
  loader();
  page.paginator = loader;
  page.loading = false;
}

// Paginas

new page.Route(plugin.id + ":start", function(page) {
    setPageHeader(page, plugin.title);
    page.model.contents = 'grid';
    page.appendItem(plugin.id + ":search:", 'search', {
      title: 'Buscar en Archive.org'
    });
    page.appendItem('', 'separator', {
      title: ''
    });
    
    if (!service.disableMyFavorites || list || list.length > 0) {
      page.appendItem('', 'separator', {
        title: 'My Favorites',
      });
  
      var list = JSON.parse(favorites.list);
      var pos = 0;
      for (var i = list.length - 1; i >= 0 && pos < 4; i--) {
        var itemmd = list[i];
        var item = page.appendItem(decodeURIComponent(itemmd.link), 'video', {
          title: decodeURIComponent(itemmd.title),
          icon: itemmd.icon ? decodeURIComponent(itemmd.icon) : null,
          description: 'Link: ' + decodeURIComponent(itemmd.link)
        });
        pos++;
      }
  
      if (list && list.length > 0) {
        page.appendItem(plugin.id + ":favorites", "video", {
          title: "Show All...",
          icon: 'https://i.postimg.cc/zGT28Cz2/favs.png'
        });
      }
    }
  
    page.appendItem('', 'separator', {
      title: 'Más Popular en Archive.org'
    });

    addDiscoverSection(page);
  
    page.appendItem("internetarchive:popular", "video", {
      title: "Show All...",
      icon: "https://i.postimg.cc/cJLV4kMN/seemore.png"
    });
  
    page.loading = false;
    popup.notify("¡Visita Archive.org y Dona si puedes!", 7);
});

new page.Route(plugin.id + ':favorites', function(page) {
    setPageHeader(page, "My Favorites");
    popup.notify("Vacia tus Favoritos desde el Menu lateral", 7);
  
    page.options.createAction('cleanFavorites', 'Vacia tus Favoritos', function() {
      favorites.list = '[]';
      popup.notify('Favoritos vaciados satisfactoriamente', 3);
      page.redirect(plugin.id + ':start');
    });
  
    var favoritesList = JSON.parse(favorites.list);
    for (var i = favoritesList.length - 1; i >= 0; i--) {
      var favorite = favoritesList[i];
      var item = page.appendItem(decodeURIComponent(favorite.link), "video", {
        title: decodeURIComponent(favorite.title),
        icon: favorite.icon ? decodeURIComponent(favorite.icon) : null,
        description: 'Link: ' + decodeURIComponent(favorite.link)
      });
    }
  
    page.loading = false;
});

new page.Route(plugin.id + ":search:(.*)", function(page, query) {
  setPageHeader(page, "Search results for: " + query);
  browseItems(page, query);
});

new page.Route("internetarchive:popular", function(page) {
  setPageHeader(page, "Popular");

  var args = {
    q: 'mediatype:movies',
    fl: ["identifier", "title", "mediatype"],
    sort: ["downloads desc"],
    rows: 100,
    output: "json"
  };

  try {
    var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
      args: args
    }));
  } catch(err) {
    page.error('No se pudieron recuperar datos de Internet Archive.');
    return;
  }

  page.loading = false;
  for (var i in c.response.docs) {
    var video = c.response.docs[i];
    if (video.mediatype === 'movies') {
      addMediaItem(page, video);
    }
  }
});

new page.Route("internetarchive:files:(.*)", function(page, id) {
  setPageHeader(page, id);
  page.model.contents = 'list';
  var encodedId = encodeURIComponent(id);
  var listingImage = "https://archive.org/services/img/" + encodedId;
  page.metadata.background = listingImage;

  var response;
  try {
    response = http.request('https://archive.org/metadata/' + encodedId);
  } catch (err) {
    page.error("No se pudieron recuperar metadatos del item.");
    page.loading = false;
    return;
  }

  var metadata = JSON.parse(response);
  if (!metadata || !metadata.files || metadata.files.length === 0) {
    page.error('No se encontraron archivos en el item seleccionado.');
    page.loading = false;
    return;
  }

  var mediaFiles = metadata.files.filter(function(file) {
    return /\.(mp4|avi|3gp|mp3|ogg|m4a)$/.test(file.name);
  });

  if (mediaFiles.length === 0) {
    page.error('No se encontraron archivos multimedia en el item seleccionado.');
    page.loading = false;
    return;
  }

  var media = {
    identifier: id,
    title: metadata.metadata.title || "Unknown Title",
    mediatype: metadata.metadata.mediatype || "Unknown Type",
    icon: "https://archive.org/services/img/" + id
  };

  mediaFiles.forEach(function(file) {
    var mediaUrl = 'https://archive.org/download/' + encodedId + '/' + encodeURIComponent(file.name);
    var type = /\.(mp4|avi|3gp)$/.test(file.name) ? 'video' : 'audio';
    page.appendItem(mediaUrl, type, {
      title: file.name.split('/').pop(), // modified line
      sources: [{ url: mediaUrl }],
      icon: listingImage
    });
  });

  page.loading = false;
  popup.notify("Algunos archivos pueden estar restringidos.", 5);
});