//Variables

var page = require('showtime/page');
var service = require('showtime/service');
var settings = require('showtime/settings');
var http = require('showtime/http');
var string = require('native/string');
var popup = require('native/popup');
var io = require('native/io');
var store = require('movian/store');
var plugin = JSON.parse(Plugin.manifest);
var logo = Plugin.path + plugin.icon;
var localVersion = plugin.version;

var tosSave = store.create('tosSave');
if (!tosSave.list) {
  tosSave.list = '[]';
}

var codeSave = store.create('codeSave');
if (!codeSave.list) {
  codeSave.list = '[]';
}

var favorites = store.create('favorites');
if (!favorites.list) {
  favorites.list = '[]';
}

var history = store.create('history');
if (!history.list) {
  history.list = '[]';
}

var playList = store.create('playList');
if (!playList.list) {
  playList.list = '[]';
}

var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36';

var background = '', theLastSearch = '', numerPages = 1, codeVerify = true, tosAccepted = false;

var jsonBest = {}, jsonIptv = {}, jsonIptvSearch = {}, jsonDescubrir = {}, dataSearch = {}, data = {}, jsonData = {}, jsonBestUrl = '', jsonIptvUrl = '', jsonIptvSearchUrl = '', jsonDescubrirUrl = '', dataSearchUrl = '', dataUrl = '', jsonDataUrl = '';

var m3uItems = [], groups = [], theLastList = '', m3uLinks = '';

var base = "https://playstr3am.netlify.app/", scrapper = base + ".netlify/functions/";

var blue = '6699CC', orange = 'FFA500', red = 'EE0000', green = '008B45', violet = '9A4DAD';

var generos = ["2025", "Acción", "Animación", "Aventura", "Bélico", "Ciencia ficción", "Comedia",
               "Crimen", "Documental", "Drama", "Familia", "Fantasía", "Historia", "Música",
               "Misterio", "Película de TV", "Romance", "Suspenso", "Terror", "Western"];

var tos = "Este plugin se proporciona con fines educativos y de aprendizaje. El creador no se hace responsable del uso que se le dé ni del contenido reproducido, el cual puede ser de terceros. El usuario asume toda la responsabilidad legal sobre el uso del plugin, asegurándose de que no infrinja derechos de autor ni leyes locales. El creador no será responsable por daños, pérdidas o problemas legales derivados del uso del plugin. El plugin está destinado a uso personal y no debe ser modificado ni distribuido para fines comerciales sin permiso. Al utilizar este plugin, aceptas estos términos.";

//Funciones

RichText = function(x) {
  this.str = x.toString();
};

RichText.prototype.toRichString = function(x) {
  return this.str;
};

function coloredStr(str, color) {
  return '<font color="' + color + '">' + str + '</font>';
}

function trim(s) {
  if (s) return s.replace(/(\r\n|\n|\r)/gm, '').replace(/(^\s*)|(\s*$)/gi, '').replace(/[ ]{2,}/gi, ' ').replace(/\t/g, '');
  return '';
}

function log(str) {
  if (service.debug) {
    console.log(str);
    print(str);
  }
}

function setPageHeader(page, title) {
  page.loading = true;
  page.type = 'directory';
  page.contents = 'items';
  page.entries = 0;

  if (page.metadata) {
    page.metadata.font = 'Roboto';
    page.metadata.title = new RichText(decodeURIComponent(title));
    page.metadata.logo = logo;
    page.metadata.icon = logo;
  }

  if (!service.disableBackground) {
    page.metadata.background = Plugin.path + 'images/background.jpg';
  }

  if (codeVerify) {
    accesUrl(page);
  }

  page.model.contents = 'list';
}

function checkUpdate(page) {
  var resp = http.request(base + "plugin.json").toString();
  const latestVersion = JSON.parse(resp).version;

  if (localVersion < latestVersion) {
    popup.notify("Version Actual: " + localVersion + ", Nueva Version Disponible: " + latestVersion, 5);
    popup.notify("Actualiza PlayStr3am desde el menu lateral.  (Triangulo)", 0xa);

    page.options.createAction("update", "Actualizar PlayStr3am", function () {
      popup.notify("Actualizando, espere 10 segundos y regrese atras...",0xa );
      page.redirect(base + "PlayStr3am.zip");
    });
  }
}

function accesUrl(page) {
  var codeSaveData = [];

  try {
      codeSaveData = JSON.parse(codeSave.list || '[]');
  } catch (e) {
      codeSaveData = [];
  }

  if (codeSave.list === '[]') {
    var credentials = popup.getAuthCredentials('Registrate previamente en', 'https://playstr3am.netlify.app/sesion', codeVerify, plugin.id);

    if (credentials.rejected) {
      page.error('No se puede continuar sin nombre de usuario y/o contraseña :(');
      return false;
    }

    if (credentials && credentials.password && credentials.username) {    
      var entry = JSON.stringify({
        name: credentials.username,
        code: credentials.password,
      });

      codeSaveData = JSON.parse(codeSave.list || '[]');
      codeSaveData.unshift(entry);
      codeSave.list = JSON.stringify(codeSaveData);
    }
  }

  try {
    var credentialsSave = JSON.parse(codeSaveData[0]);
    var response = http.request(scrapper + "sesion?username=" + credentialsSave.name + '&password=' + credentialsSave.code, {
        headers: { 'User-Agent': UA }
    });
 
    var sesion = JSON.parse(response);
    var estado = sesion.isActive;

    if (!estado) {
        popup.notify("Visita \'https://playstr3am.netlify.app/sesion\'", 0xa);
        throw new Error('Tu Cuenta se encuentra Desactivada');
    } else {
        popup.notify("¡Tu Cuenta esta Activa!", 5);
        popup.notify("¡Bienvenid@, " + credentialsSave.name + " Disfruta del Contenido!",5 );
        codeVerify = false;
    }

    return true;
  } catch (e) {
    popup.notify("Visita \'https://playstr3am.netlify.app/sesion\'", 0xa);
    page.error('Tu Cuenta se encuentra Desactivada');
    return false;
  }
}

function addItem(page, url, title, image, duration, sinopsis, genres, cast, similar, rating, clasification, color, linkN, results, backdrops, year, budget) {
  var item;
  if (color === '') {
    var type = 'video';
    var link = url.match(/([\s\S]*?):(.*)/);
    var linkUrl = 0;
    image = image ? image : Plugin.path + "images/video.png";
    var playlistType = isPlaylist(url);
    if (playlistType) {
      link = linkUrl = 'listM3u:' + encodeURIComponent(url) + ':listM3u:' + escape(title);
      type = 'm3u';
    } else if (link && !link[1].toUpperCase().match(/HTTP/) && !link[1].toUpperCase().match(/RTMP/)) {
      link = linkUrl = plugin.id + ':' + url + ':' + escape(title);
    } else {
      linkUrl = url.toUpperCase().match(/M3U8/) || url.toUpperCase().match(/\.SMIL/) ? 'hls:' + url : url;
      link = 'videoparams:' + JSON.stringify({
        title: title,
        icon: image ? image : Plugin.path + "images/video.png",
        sources: [{ url: linkUrl }],
        no_fs_scan: true,
        no_subtitle_scan: true,
      });
    }

    if (!linkUrl) {
      item = page.appendPassiveItem('video', '', {
        title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
        icon: image,
      });
    } else if (results === 'metadata') {
      item = page.appendItem(link, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
        icon: image,
        tagline: new RichText((duration ? coloredStr('<b>Duracion: </b>', blue) + duration : '')),
        source: new RichText(coloredStr('<b>PlayStr3am</b>', violet)),
        description: new RichText((sinopsis ? coloredStr('<b>Sinopsis: </b>', orange) + sinopsis : '')),
      });
    } else {
      if (results === 'audio') {
        item = page.appendItem(link, 'video', {
          title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
          icon: image,
          source: [{ url: link }],
        });
      } else {
        item = page.appendItem(link, 'video', {
          title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
          icon: image,
          source: new RichText(coloredStr('<b>PlayStr3am</b>', violet)),
          description: new RichText((linkUrl ? coloredStr('<b>Link: </b>', orange) + linkUrl + '\n' : '') + 
        (image ? coloredStr('<b>Imagen URL: </b>', orange) + image : '') || 'Vacío'),
        });
      }
    }
  } else {
    if (sinopsis === 'Si' || sinopsis === 'No') {
      var departament = departamentAsign(page, similar);

      item = page.appendItem(url, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', color)),
        icon: image,
        genre: new RichText((duration ? coloredStr('<b>Caracterizando: </b>', green) + duration + '\n' : '') +         
          (genres ? coloredStr('<b>Sexo: </b>', blue) + genres + '\n' : '') +
          (sinopsis ? coloredStr('<b>Contenido para Adultos: </b>', violet) + sinopsis : '')),
        rating: rating,
        backdrops: backdrops ? backdrops : '',
        tagline: new RichText((cast ? coloredStr('<b>Nombre Real: </b>', orange) + cast + '\n' : '') +
          (departament ? coloredStr('<b>Departamento: </b>', orange) + departament : '')),
        source: new RichText(coloredStr('<b>PlayStr3am</b>', violet)),
        description: new RichText((clasification ? coloredStr('<b>Participaciones Destacadas:</b>', orange) + '\n- ' +
          clasification + '\n - ' + linkN + '\n - ' + results : '')),
      });
    } else if (duration === '' && sinopsis === '' && genres === '' && cast === '' && similar === '' && rating === '' && clasification === '' && linkN === '' && results === '') {
      item = page.appendItem(url, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', color)),
        icon: image,
        backdrops: backdrops ? backdrops : '',
        source: new RichText(coloredStr('<b>PlayStr3am</b>', violet)),
      });
    } else {
      item = page.appendItem(url, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', color)),
        icon: image,
        year: year,
        genre: new RichText((genres ? coloredStr('<b>Género: </b>', violet) + genres + '\n' : '') +
          (cast ? coloredStr('<b>Cast: </b>', blue) + cast + '\n' : '') +
          (similar ? coloredStr('<b>Recomendado: </b>', green) + similar : '')),
        rating: rating,
        backdrops: backdrops ? backdrops : '',
        tagline: new RichText((linkN ? coloredStr('<b>Servidores Disponibles: </b>', orange) + linkN + '\n' : '') +
         (duration ? coloredStr('<b>Duracion: </b>', orange) + duration + '\n' : '') + 
         (clasification ? coloredStr('<b>Clasificacion: </b>', orange) + clasification + '\n' : '') +
         (budget ? coloredStr('<b>Presupuesto: </b>', orange) + budget + '\n' : '') +
         (results ? coloredStr('<b>' + results + '</b>', red) : '')),
        source: new RichText(coloredStr('<b>PlayStr3am</b>', violet)),
        description: new RichText((sinopsis ? coloredStr('<b>Sinopsis: </b>', orange) + sinopsis : '')),
      });
    }
  }
  return item;
}

// TXT Personalizados

function backdropsSorter(page, collage, arrays) {
  var backdrops = collage ? collage : [];
  if (arrays.length > 0) {
    for (var i = 0; i < arrays.length; i++) {
      var arraysImage = arrays[i];
      backdrops.push({url: arraysImage});
    }
  }
  backdrops.push({url: logo});
  return backdrops;
}

function controlArrays(page, arrays) {
  var global = '';       
  if (arrays.length > 0) {
    for (var i = 0; i < arrays.length; i++) {
      var arraysName = arrays[i];
      if (arraysName !== 'Desconocido') {
        var arg;
        if (global === '') {
          arg = '';
        } else {
          arg = ', ';
        }
        global = global + arg + arraysName;
      }
    }
    global = global + '.';
  }
  return global;
}

function departamentAsign(page, seccion) {
  var departament = { 
    'Acting': 'Actuación',
    'Art': 'Arte',
    'Camera': 'Cámara',
    'Creator': 'Creador',
    'Directing': 'Dirección',
    'Editing': 'Edición',
    'Visual Effects': 'Efectos Visuales',
    'Crew': 'Equipo',
    'Writing': 'Escritura',
    'Lighting': 'Iluminación',
    'Production': 'Producción',
    'Sound': 'Sonido',
    'Costume & Make-Up': 'Vestuario y maquillaje'
  }
  return departament[seccion];
}

function sloganCustom(page, seccion) {
  var arg;
  
  if (!service.eneableKids) {
    if (service.selectDescubrir === 'Best') {
      arg = 'Las Mejores ' + seccion;
    } else if (service.selectDescubrir === 'Años') {
      arg = 'Lo Mejor de ' + seccion;
    } else if (service.selectDescubrir === 'Reparto') {
      var slogans = {
        'Acting': 'Emociones reales en cada Actuación',
        'Writing': 'Historias que cobran vida con palabras',
        'Directing': 'Visión y arte detrás de la cámara',
        'Sound': 'Sonidos que elevan la narrativa',
        'Crew': 'El motor que impulsa cada producción',
        'Editing': 'Cortes precisos que tejen la historia',
        'Camera': 'Capturando instantes inolvidables',
        'Costume & Make-Up': 'Transformando personajes con estilo',
        'Production': 'Organización y pasión en cada proyecto',
        'Visual Effects': 'Imaginación que crea universos',
        'Art': 'Diseñando emociones a través del arte',
        'Lighting': 'Iluminando escenas con magia',
        'Creator': 'Innovación y creatividad sin límites'
      };
      arg = slogans[seccion] || 'Lo Mejor de ' + seccion;
    } else if (service.selectDescubrir === 'Generos') {
      var slogans = {
        'Acción': 'Siente la Acción sin límites',
        'Animación': 'Colores y magia en Animación',
        'Aventura': 'Descubre la Aventura sin fronteras',
        'Bélico': 'Batallas épicas, vive lo Bélico',
        'Ciencia ficción': 'Explora el futuro en Ciencia ficción',
        'Comedia': 'Ríe a carcajadas con Comedia',
        'Crimen': 'Intriga real en Crimen',
        'Documental': 'Explora la realidad en Documental',
        'Drama': 'Sentimientos profundos en Drama',
        'Familia': 'Diversión y unión en Familia',
        'Fantasía': 'Sueña despierto con Fantasía',
        'Historia': 'Revive épocas con Historia',
        'Música': 'Ritmos vibrantes en Música',
        'Misterio': 'Descifra enigmas en Misterio',
        'Película de TV': 'Entretenimiento brillante en Película de TV',
        'Romance': 'Amor y pasión en Romance',
        'Suspenso': 'Tensión y misterio en Suspenso',
        'Terror': 'Siente el miedo en Terror',
        'Western': 'Espíritu salvaje en Western'
      };
      arg = slogans[seccion] || 'Lo Mejor de ' + seccion;
    } else {
      arg = 'Lo Mejor de ' + seccion;
    }
  } else {
    var slogansKids = {
      'Acción': '¡Corre, juega y vive aventuras!',
      'Animación': 'Colores y dibujos para soñar',
      'Aventura': 'Explora mundos mágicos y divertidos',
      'Bélico': 'Historias de héroes y amistad',
      'Ciencia ficción': 'Viaja a planetas de ensueño',
      'Comedia': 'Risas y juegos para compartir',
      'Crimen': 'Cuentos de misterio y detectives',
      'Documental': 'Descubre el mundo de verdad',
      'Drama': 'Historias que tocan el corazón',
      'Familia': 'Diversión en familia, siempre juntos',
      'Fantasía': 'Sueña con castillos y dragones',
      'Historia': 'Viaja en el tiempo a cuentos viejos',
      'Música': 'Canciones y ritmos para bailar',
      'Misterio': 'Descubre secretos en cuentos fantásticos',
      'Película de TV': 'Historias en pantalla para soñar',
      'Romance': 'Amistad y dulces cuentos de amor',
      'Suspenso': 'Descubre secretos en la penumbra',
      'Terror': 'Cuentos de terror para corazones valientes',
      'Western': 'Aventuras en el viejo oeste'
    };
    arg = slogansKids[seccion] || 'Lo Mejor de ' + seccion;
  }
  
  return arg;
}

function age_classification(page, age) {
  var clasification;
  if (age === '' || age === 'NR' || age === 'Btl' || age === 'si' || age === 'Ai' || age === 'ok' ||
      age === 'Ershad' || age === 'Release' || age === '-' || age === 'IIA' || age === 'S' ||
      age === '3.8' || age === '7.0' || age === 'III' || age === 'Mono Originals' || age === 'IIB' || age === 'IMDb') {
    clasification = ' - No hay datos oficiales.';
  } else if (age === 'C' || age === 'K' || age === 'TV-Y' || age === '0' || age === 'KN' || age === '0+' || age === '3') {
    clasification = ' - Apta para niños de todas las edades.';
  } else if (age === 'TV-Y7' || age === 'TV-Y7-FV' || age === '8' || age === 'K-7' || age === '9' ||
             age === '6' || age === 'TE+7' || age === 'I' || age === '7' || age === '7+' || age === '6+') {
    clasification = ' - Dirigida a niños mayores de 7 años; puede contener temas o violencia leve.';
  } else if (age === 'G' || age === 'TV-G' || age === 'ATP' || age === 'L' || age === 'U' ||
             age === 'APTA' || age === 'FSK' || age === '0' || age === 'all' || age === 'AP' ||
             age === 'AL' || age === 'Toda La Familia' || age === 'E' || age === 'All' ||
             age === 'Genel İzleyici Kitlesi' ||   age === 'TP' || age === 'ALL' || age === 'atp' || age === 'atp ') {
    clasification = ' - Apta para todos los públicos, sin contenido inapropiado para niños.';
  } else if (age === 'R' || age === 'PG' || age === 'PG-13' || age === 'TV-PG' || age === 'B' ||
             age === '12A' || age === 'UA' || age === '12+' || age === '12+' || age === 'PG12' ||
             age === 'PG13' || age === '12세 이상 관람가' || age === 'K12' || age === '12' ||
             age === 'K-12' || age === '+13' || age === 'G+' || age === 'P13' || age === '13' ||
             age === '輔12級' || age === 'M/12' || age === 'U/A 13+' || age === 'e 12' ||
             age === '11' || age === '13+' || age === 'Κ-12' || age === '10' || age === 'N-13') {
    clasification = ' - Se aconseja la supervisión de los padres para menores de 13 años debido a posible contenido sensible (violencia, lenguaje, etc.).';
  } else if (age === 'T' || age === 'M/16' || age === 'K-16' || age === 'B-15' || age === 'MA15+' ||
             age === 'TV-14' || age === '18A' || age === '15+' || age === '17+' || age === '14A' ||
             age === 'SAM 16' || age === '16' || age === 'N-16' || age === 'M/14' || age === '14' ||
             age === '16+' || age === '15세이상관람가' || age === 'Κ-15' || age === 'NC16' || 
             age === '16 Anos' || age === 'NC-17' || age === 'VM14' || age === '15' || age === 'AP16' ||
             age === 'R15+' || age === 'TE' || age === '14+' || age === '+16' || age === 'U/A 16+') {
    clasification = ' - Dirigida a adolescentes; puede contener temas maduros o contenido sensible (violencia, desnudos, consumo de sustancias, etc.)';
  } else if (age === 'A' || age === 'AA' || age === 'M' || age === 'R18+' || age === 'TV' ||
             age === '18' || age === '19' || age === '청소년 관람불가' || age === 'R21' || age === 'R 18+' ||
             age === 'A ' || age === 'SR' || age === 'M18' || age === '保護級' || age === '19+' ||
             age === 'R-18' || age === 'D' || age === '18+' || age === 'C18' || age === '21+' ||
             age === '+18' || age === 'TV-MA') {
    clasification = ' - Solo para adultos, puede incluir violencia extrema, lenguaje fuerte o contenido sexual explícito.';
  }
  return clasification;
}

//Configuraciones

service.create(plugin.title, plugin.id + ':start', 'PlayStr3am', true, logo);
settings.globalSettings(plugin.id, plugin.title, logo, plugin.synopsis);
settings.createInfo('info', logo, new RichText('Plugin desarrollado por <b> ElSuacht</b>, \n<b>' + plugin.id + '</b>, \n' + 'version: <b>' + localVersion + '</b> \n'));

settings.createDivider("Peliculas y Series");

settings.createMultiOpt('selectDescubrir', 'Descubre lo Mejor por', [
    ['Años', 'Años'],
    ['Generos', 'Generos'],
    ['Best', 'Peliculas o Series'],
    ['Reparto', 'Reparto'],
    ['undefined', 'Predeterminado', true],
  ], function(v) {
  service.selectDescubrir = v;
});
settings.createBool('eneableKids', 'Activar Modo Infantil', false, function(v) {
  service.eneableKids = v;
});

settings.createDivider("IPTV");

settings.createMultiOpt('selectCountry', 'Escoger Region', [
    ['Argentina', 'Argentina'],
    ['Bolivia', 'Bolivia'],
    ['Brasil', 'Brasil'],
    ['Canada', 'Canada'],
    ['Chile', 'Chile'],
    ['Colombia', 'Colombia'],
    ['Costa Rica', 'Costa Rica'],
    ['Cuba', 'Cuba'],
    ['Ecuador', 'Ecuador'],
    ['España', 'España'],
    ['Guatemala', 'Guatemala'],
    ['Honduras', 'Honduras'],
    ['Mexico', 'Mexico'],
    ['Nicaragua', 'Nicaragua'],
    ['Panama', 'Panama'],
    ['Paraguay', 'Paraguay'],
    ['Peru', 'Peru'],
    ['Puerto Rico', 'Puerto Rico'],
    ['Republica Dominicana', 'Republica Dominicana'],
    ['Salvador', 'Salvador'],
    ['Uruguay', 'Uruguay'],
    ['USA', 'USA'],
    ['Venezuela', 'Venezuela'],
    ['undefined', 'undefined', true],
  ], function(v) {
  service.selectCountry = v;
});
settings.createBool('disableAdultos', 'Mostrar Contenido +18', false, function(v) {
  service.disableAdultos = v;
});

settings.createDivider("Listas M3U");

settings.createBool('enabledM3uOp', 'Optimizar Listas Grandes', false, function(v) {
  service.disableM3uOp = v;
});
settings.createAction('cleanPlayList', 'Vacía Tus Listas', function() {
  playList.list = '[]';
  popup.notify('Tus Listas M3U se han vaciado exitosamente', 2);
});

settings.createDivider("General");

settings.createBool("backgroundEnabled", "Ocultar Background", false, function(v) {
  service.disableBackground = v;
});
settings.createAction('closeSesion', 'Cerrar Sesion', function() {
  codeVerify = true;
  codeSave.list = '[]';
  popup.notify('Sesion cerrada exitosamente', 2);
});

// Principal

function mainPage(page) {
  setPageHeader(page, plugin.title);
  var historial = JSON.parse(history.list || '[]');
  var favoritos = JSON.parse(favorites.list || '[]');
  var playLists = JSON.parse(playList.list || '[]');
  numerPages = 1;

  if (tosSave.list === '[]') {
    if (popup.message(tos, true, true)) {
      tosAccepted = true;
      tosSave.list = '[1]';
    } else {
      page.error('No puedes usar el plugin sin aceptar los Términos y Condiciones.');
      return;
    }
  }

  checkUpdate(page);

  if (favoritos.length > 0) {
    page.options.createAction('gotoFavoritos', 'Favoritos', function() {
      page.redirect(plugin.id + ':favoritesandRecord:favorites');
    });
  }

  if (historial.length > 0) {
    page.options.createAction('gotoHistorial', 'Historial', function() {
      page.redirect(plugin.id + ':favoritesandRecord:history');
    });
  }

  addListM3u(page);

  page.options.createAction('gotoInternetArchive', 'Internet Archive', function() {
    page.redirect(plugin.id + ':internetArchive:');
  });

  page.options.createAction('gotoIptv', 'IPTV', function() {
    page.redirect(plugin.id + ':iptv');
  });

  page.appendItem("searchJson:", "search", {
      title: "Buscar Peliculas y Series...",
  });

  if (service.selectDescubrir === 'undefined' && !service.eneableKids) {
    page.appendItem('', 'separator', { title: '', });

    for (var i = 0; i < generos.length; i++) {
      var image = Plugin.path + 'images/genres/' + encodeURIComponent(generos[i]) + '.png';
      var backdrops = [{url: image}]
      addItem(page, 'searchJson:' + generos[i], '', image, '', '', '', '', '', '', '', orange, '', '', backdrops, '', '');
    } 

    if (playLists.length > 0) {
      page.appendItem('', 'separator', {
        title: new RichText(coloredStr('<b>==★== <i> Listas M3U</i> ==★== </b>', orange)),
      });

      showListM3u(page);  
    }
    page.model.contents = 'grid';
  } else {
    if (service.selectDescubrir === 'Best' && !service.eneableKids) {
      page.metadata.title = 'Descubre lo Mejor Calificado';
    } else if (service.eneableKids) {
      page.metadata.title = 'Zona Infantil';
    } else {
      page.metadata.title = 'Descubre lo Mejor por ' + service.selectDescubrir;
    }

    var mode;
    if (service.eneableKids) {
      mode = 'Infantil';
    } else {
      mode = service.selectDescubrir;
    }
    
    var url = scrapper + 'descubrir?query=' + mode;
    if (jsonBestUrl !== url || jsonBestUrl === '') {
      var response;
      try {
          response = http.request(url, {
              headers: {
                  'User-Agent': UA,
              },
          });
      } catch (err) {
          page.error('No se pudo obtener datos');
          page.loading = false;
          return;
      }
      jsonBest = JSON.parse(response);
      jsonBestUrl = url;
    }

    var secciones = jsonBest.items;
    var seccion = Object.keys(secciones);

    for (var i = 0; i < seccion.length; i++) {
        var seccionTitle = seccion[i];
        var canales = jsonBest.items[seccionTitle];
        var canal = Object.keys(canales);

        if (service.selectDescubrir === 'Años') {
          seccionTitle = seccionTitle.replace(/^y/i, '');
        }

        var arg = sloganCustom(page, seccionTitle);
 
        page.appendItem('', 'separator', { title: '', });
        page.appendItem('', 'separator', {
          title: new RichText(coloredStr('<b>==★== <i>' + arg + '</i> ==★== </b>', orange)),
        });

        var pos = 0;
        for (var j = 0; j < canal.length; j++) {
          var canalTitle = canal[j];
          var canalData = canales[canalTitle];
          var id = canalData.id ? canalData.id : 'null';
          var route = 'jsonContent:' + canalTitle + ':' + id;
          var year = canalData.year ? canalData.year : '';
          var budget = canalData.budget ? canalData.budget : '';
          var image = canalData.still_path ? canalData.still_path : Plugin.path + 'images/video.png';

          var genres = canalData.genres ? canalData.genres : [];
          var genresGlobal = controlArrays(page, genres);
          var cast = canalData.cast ? canalData.cast : [];
          var castGlobal = controlArrays(page, cast);
          var similar = canalData.similar ? canalData.similar : [];
          var similarGlobal = controlArrays(page, similar);

          var backdrops = [];
          if (service.selectDescubrir === 'Reparto') {
            var collage = [{url: canalData.profile_path}];
            var background = canalData.backdrops_path ? canalData.backdrops_path : [];
            var poster = canalData.poster_path ? canalData.poster_path : [];
            background = background.concat(poster);
            backdrops = backdropsSorter(page, collage, background);
          } else {
            var collage = [{url: canalData.still_path}, {url: canalData.background}];
            var castImage = canalData.castImage ? canalData.castImage : [];
            backdrops = backdropsSorter(page, collage, castImage);
          }

          var duration = '';
          if (canalData.media_type != 'tv') {
            duration = canalData.duration ? canalData.duration : '';
          }

          if (pos < 4) {
            if (service.selectDescubrir === 'Reparto') {
              route = 'descubrir:' + seccionTitle + ':' + canalTitle;
              image = canalData.profile_path ? canalData.profile_path : Plugin.path + 'images/avatars.png';

              var adult = '';
              if (canalData.adult === true) {
                adult = 'Si';
              } else if (canalData.adult === false) {
                adult = 'No';
              }

              var item = addItem(page, route, canalTitle, image, '', adult, canalData.gender, canalData.original_name, canalData.departament, canalData.rating, canalData.known_for[0], orange, canalData.known_for[1], canalData.known_for[2], backdrops, '', '');
              addOptionForAddingToMyFavorites(item, route, canalTitle, image, '', canalData.adult, canalData.gender, canalData.original_name, canalData.departament, canalData.raking, '', backdrops, 'cast');
            } else {
              var item = addItem(page, route, canalTitle, image, duration,  canalData.overview, genresGlobal, castGlobal, similarGlobal, canalData.rating, canalData.age_classification, orange, '', '', backdrops, year, budget);
              addOptionForAddingToMyFavorites(item, route, canalTitle, image, duration, canalData.overview, genresGlobal, castGlobal, similarGlobal, canalData.rating, canalData.age_classification, backdrops, 'json');
            }
          }
        
          if (pos === 4) {
            route = 'descubrir:' + seccionTitle + ':';
            if (service.selectDescubrir === 'Reparto') {
              image = canalData.profile_path ? canalData.profile_path : Plugin.path + 'images/avatars.png';
              addItem(page, route, 'Mas de ' + seccionTitle, image, '', adult, canalData.gender, canalData.original_name, canalData.departament, canalData.raking, canalData.known_for[0], orange, canalData.known_for[1], canalData.known_for[2], backdrops, '', '');
            } else {
              addItem(page, route, 'Mas de ' + seccionTitle, image, duration,  canalData.overview, genresGlobal, castGlobal, similarGlobal, canalData.rating, canalData.age_classification, orange, '', '', backdrops, year, budget);
            }
            break;
          }
          pos++;
        }
    }
    page.model.contents = 'list';
  }
  page.loading = false;
}

//Favoritos 

function addOptionForAddingToMyFavorites(item, route, title, icon, duracion, sinopsis, genres, cast, similar, rating, clasification, backdrops, type) {
  item.addOptAction('Agrega \'' + title + '\' a Tus Favoritos', function() {
    var entry = JSON.stringify({  route: route, title: title, icon: icon, cast: cast,
      duracion: duracion, genres: genres, similar: similar, sinopsis: sinopsis,
      rating: rating, age_classification: clasification, type: type, backdrops: backdrops,
    });
    favorites.list = JSON.stringify([entry].concat(eval(favorites.list)));
    popup.notify('\'' + title + '\' a sido Agregado a Tus Favoritos.', 2);
  });
}

function addOptionForRemovingFromMyFavorites(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de Tus Favoritos?', function() {
    var list = JSON.parse(favorites.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminado de Tus Favoritos.', 2);
    list.splice(pos, 1);
    favorites.list = JSON.stringify(list);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function showFavorites(page) {
  var list;
  try {
    list = JSON.parse(favorites.list);
  } catch (e) {
    list = [];
  }

  var parsedFavorite = [];
  for (var i in list) {
    try {
      parsedFavorite.push(JSON.parse(list[i]));
    } catch (e) {}
  }

  var ruteRemoving = (parsedFavorite.length === 1 ? ':start' : ':favoritesandRecord:');
  var pos = 0;
  var sections = [
    { name: "Películas y Series", types: ['json'] },
    { name: "Reparto", types: ['cast'] },
    { name: "Internet Archive e Historial", types: ['archive', 'iptv', 'movie'] }
  ];

  for (var s = 0; s < sections.length; s++) {
    var currentSection = sections[s];
    var items = parsedFavorite.filter(function(item) {
      return currentSection.types.indexOf(item.type) !== -1;
    });

    if (items.length > 0) {
      page.appendItem('', 'separator', {
        title: new RichText(coloredStr('<b>==★== <i>' + currentSection.name + '</i> ==★== </b>', orange))
      });

      for (var j = 0; j < items.length; j++) {
        var itemmd = items[j];
        var image = itemmd.icon ? itemmd.icon : Plugin.path + 'images/video.png';

        var item;
        if (itemmd.type === 'cast') {
          var adult = '';
          if (itemmd.sinopsis === true) {
            adult = 'Si';
          } else if (itemmd.sinopsis === false) {
            adult = 'No';
          }
          
          item = addItem(page, itemmd.route, itemmd.title, image, '', adult, itemmd.genres, itemmd.cast, itemmd.similar, itemmd.rating, itemmd.clasification, orange, '', '', itemmd.backdrops, '', '');
        } else {
          item = addItem(page, itemmd.route, itemmd.title, image, itemmd.duracion, itemmd.sinopsis, itemmd.genres, itemmd.cast, itemmd.similar, itemmd.rating, itemmd.age_classification, orange, '', '', itemmd.backdrops, '', '');
        }
        addOptionForRemovingFromMyFavorites(page, item, itemmd.title, pos, ruteRemoving);
        pos++;
      }
    }
  }
}

function favoriteAndPagesHistory(page, route) {
  page.options.createAction('gotoInicio', 'Inicio', function() {
    page.redirect(plugin.id + ':start');
  });

  if (route === 'favorites') {
    setPageHeader(page, 'Tus Favoritos');
    showFavorites(page);

    page.options.createAction('cleanFavorites', 'Vacía Tus Favoritos', function() {
      favorites.list = '[]';
      popup.notify('Tus Favoritos se han vaciado exitosamente', 3);
      page.redirect(plugin.id + ':start');
    });
    popup.notify("Puedes borrar todos Tus Favoritos desde el menu lateral. (Triangulo)", 3);
  } else if (route === 'history'){
    setPageHeader(page, "Historial de Busquedas");
    page.model.contents = 'grid';
    showHistory(page);

    page.options.createAction('cleanRecord', 'Vacía Tu Historial', function() {
      history.list = '[]';
      popup.notify('Tu Historial de Busqueda se ha vaciado exitosamente', 3);
      page.redirect(plugin.id + ':start');
    });  
    popup.notify("Puedes borrar todo Tu Historial desde el menu lateral. (Triangulo)", 3);
  }
  page.loading = false;
}

//BUSCAR

function addSearchToHistory(page, title, type) {
    try {
        if (title) {
            for (var i = 0; i < generos.length; i++) {
                if (generos[i].toLowerCase() === title.toLowerCase()) {
                    return;
                }
            }

            var historyData = JSON.parse(history.list || '[]');

            for (var i = 0; i < historyData.length; i++) {
                try {
                    var existingEntry = JSON.parse(historyData[i]);
                    if (existingEntry.title.toLowerCase() === title.toLowerCase() && existingEntry.type.toLowerCase() === type.toLowerCase()) {
                        return;
                    }
                } catch (e) {
                }
            }

            var entry = JSON.stringify({ title: title, type: type });
            historyData.unshift(entry);
            history.list = JSON.stringify(historyData);
        }
    } catch (e) {
        popup.notify('Error al guardar la búsqueda: ' + e.message, 5);
    }
}

function addOptionForRemovingFromMyHistory(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de tu Historial?', function() {
    var historyData = JSON.parse(history.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminada.', 2);
    historyData.splice(pos, 1);
    history.list = JSON.stringify(historyData);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function showHistory(page) {
    var historyData = [];
    try {
        historyData = JSON.parse(history.list || '[]');
    } catch (e) {
        historyData = [];
    }
    
    var parsedHistory = [];
    for (var i in historyData) {
        try {
            parsedHistory.push(JSON.parse(historyData[i]));
        } catch (e) {}
    }
 

    var ruteRemoving = (parsedHistory.length === 1 ? ':start' : ':favoritesandRecord:');
    
    var pos = 0;
    var sections = [
        { type: 'movie', seccion: 'Películas y Series', routePrefix: 'searchJson:', image: Plugin.path + 'images/search.png' },
        { type: 'iptv', seccion: 'IPTV', routePrefix: 'iptvJson::', image: Plugin.path + 'images/iptv.png' },
        { type: 'archive', seccion: 'Internet Archive', routePrefix: 'internetArchiveFiles::', image: Plugin.path + 'images/internet.jpg' }
    ];
    
    for (var s = 0; s < sections.length; s++) {
        var currentSection = sections[s];
        var items = parsedHistory.filter(function(item) {
            return item.type === currentSection.type;
        });
        
        if (items.length > 0) {
            page.appendItem('', 'separator', {
                title: new RichText(coloredStr('<b>==★== <i>' + currentSection.seccion + '</i> ==★== </b>', orange))
            });
            
            for (var j = 0; j < items.length; j++) {
                var itemmd = items[j];
                var route = currentSection.routePrefix + itemmd.title;

                var item = addItem(page, route, itemmd.title, currentSection.image, '', '', '', '', '', '', '', orange, '', '', '', '', '');                
                addOptionForAddingToMyFavorites(item, route, itemmd.title, currentSection.image, '', '', '', '', '', '', '', '', itemmd.type);
                addOptionForRemovingFromMyHistory(page, item, itemmd.title, pos, ruteRemoving);
                pos++;
            }
        }
    }
}


//ProcesarM3U

function isPlaylist(pl) {
  pl = unescape(pl).toUpperCase();
  var extension = pl.split('.').pop();
  var lastPart = pl.split('/').pop();
  if (pl.substr(0, 4) == 'M3U:' || (extension == 'M3U' && pl.substr(0, 4) != 'HLS:') || lastPart == 'PLAYLIST' ||
    pl.match(/TYPE=M3U/) || pl.match(/BIT.DO/) || pl.match(/BIT.LY/) || pl.match(/GOO.GL/) ||
    pl.match(/TINYURL.COM/) || pl.match(/RAW.GITHUB/) || pl.match(/PS3.PHP?/)) {
    return 'm3u';
  }
  return false;
}

function addListM3u(page) {
  page.options.createAction('addPlaylistM3u', 'Ingresar lista M3U', function() {
    var result = popup.textDialog('Ingresa la URL de tu lista M3U:\n' +
      'http://bit.ly/ejemplo o bit.ly/ejemplo o solo ejemplo', true, true);
    if (!result.rejected && result.input) {
      var link = result.input;
      if (!link.match(/\./)) {
        link = 'http://bit.ly/' + link;
      }
      if (!link.match(/:\/\//)) {
        link = 'http://' + link;
      }
      var result = popup.textDialog('Ingresa el nombre de tu lista M3U:', true, true);
      if (!result.rejected && result.input) {
        var entry = JSON.stringify({
          title: result.input,
          link: encodeURIComponent(link),
        });
        playList.list = JSON.stringify([entry].concat(eval(playList.list)));
        popup.notify(result.input + ' - A sido añadida a tus listas', 2);
        page.flush();
        page.redirect(plugin.id + ':start');
      }
    }
  });
}

function addOptionForRemovingFromMyPlayList(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de Tus Listas M3U?', function() {
    var list = JSON.parse(playList.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminado de Tus Listas.', 2);
    list.splice(pos, 1);
    playList.list = JSON.stringify(list);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function showListM3u(page) {
  var list;
  try {
    list = JSON.parse(playList.list);
  } catch (e) {
    list = [];
  }

  var pos = 0;
  for (var i in list) {
    var itemmd = JSON.parse(list[i]);
    var route = 'listM3u:' + itemmd.link + ':listM3u:' + itemmd.title;

    var item = addItem(page, route, itemmd.title, Plugin.path + 'images/m3u.png', '', '', '', '', '', '', '', orange, '', '', '', '', '');
    addOptionForRemovingFromMyPlayList(page, item, itemmd.title, pos, ':start');
    pos++;
  }
}

function readAndParseM3U(page, pl, m3u) { 
  var title = page.metadata.title;
  page.loading = true;
  if (!m3u) {
    page.metadata.title = 'Buscando Opciones...';
    try {
      m3u = http.request(decodeURIComponent(pl), {
        headers: {
          'User-Agent': UA,
        },
      }).toString().split('\n');
    } catch (err) {
        page.error('No se pudo obtener datos');
        page.loading = false;
        return;
    }
  };
  theLastList = pl;
  m3uItems = [];
  groups = [];
  var m3uUrl = '',
    m3uTitle = '',
    m3uImage = '',
    m3uGroup = '';
  var line = '',
    m3uRegion = '',
    m3uEpgId = '',
    m3uHeaders = '';
  m3uUA = '';

   console.log("Elementos cargados en m3uItems:", m3uItems);

  for (var i = 0; i < m3u.length; i++) {
    page.metadata.title = 'Cargando Contenido...';
    line = m3u[i].trim();
    if (line.substr(0, 7) != '#EXTM3U' && line.indexOf(':') < 0 && line.length != 40) continue;
    line = string.entityDecode(line.replace(/[\u200B-\u200F\u202A-\u202E]/g, ''));

    switch (line.substr(0, 7)) {
      case '#EXTM3U':
        var match = line.match(/region=(.*)\b/);
        if (match) {
          m3uRegion = match[1];
        }
        break;

      case '#EXTINF':
        var match = line.match(/#EXTINF:.*,(.*)/);
        if (match) {
          m3uTitle = match[1].trim();
        }

        match = line.match(/group-title="([\s\S]*?)"/);
        if (match) {
          m3uGroup = match[1].trim();
          if (groups.indexOf(m3uGroup) < 0) {
            groups.push(m3uGroup);
          }
        }

        match = line.match(/tvg-logo=["|”]([\s\S]*?)["|”]/);
        if (match) {
          m3uImage = match[1].trim();
        }

        m3uItems.push({
          title: m3uTitle ? m3uTitle : line,
          url: m3u[i + 1] ? m3u[i + 1].trim() : 'URL no disponible', // URL es la línea siguiente
          group: m3uGroup,
          logo: m3uImage,
          region: m3uRegion,
        });

        m3uUrl = '', m3uTitle = '', m3uImage = '', m3uGroup = '';
        break;
    }
  }
  console.log("Elementos cargados en m3uItems:", m3uItems);
  page.metadata.title = title;
}

function showM3U(page, pl) {
  var num = 0;
  for (var i in groups) {
    page.appendItem('', 'separator', { title: '', });
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>' + groups[i] + '</i> ==★== </b>', orange)),
    });

    var pos = 0;
    for (var j in m3uItems) {
      if (m3uItems[j].group === groups[i]) {
        if (pos < 4) {
          addItem(page, m3uItems[j].url, m3uItems[j].title, m3uItems[j].logo, m3uItems[j].duracion, m3uItems[j].sinopsis, '', '', '', '', '', '', '', '', '', '', '');
        }

        if (groups[i] && pos === 4) {
          var route = 'listM3u:' + encodeURIComponent(pl) + ':groupM3u:' + groups[i];
          addItem(page, route, 'Mas de ' + groups[i], m3uItems[j].logo, '', '', '', '', '', '', '', orange, '', '', '', '', '');
          break;
        }
        pos++;
      }
    }
    num++;
  }

  for (var i in m3uItems) {
    if (m3uItems[i].group) {
      continue;
    }
    var extension = m3uItems[i].url.split('.').pop().toUpperCase();
    var itemLogo = m3uItems[i].logo ? m3uItems[i].logo : Plugin.path + "images/m3u.png";
    var link = encodeURIComponent(m3uItems[i].url);
    var route = 'listM3u:' + link + ':listM3u:' + m3uItems[i].title;

    if (isPlaylist(m3uItems[i].url) || (m3uItems[i].url == m3uItems[i].title)) {
      var item = addItem(page, route, m3uItems[i].title, itemLogo, '', '', '', '', '', '', '', orange, '', '', '', '', '');
      num++;
    } else {
      addItem(page, m3uItems[i].url, m3uItems[i].title, itemLogo, '', '', '', '', '', '', '', '', '', '', '', '', '');
      num++;
    }
    page.metadata.title = 'Agregando Items ' + num + ' de ' + m3uItems.length;
  }
}

function pagesM3u(page, title, route, pl) {
  setPageHeader(page, decodeURIComponent(title));
  page.model.contents = 'grid';
  
  if (route === 'listM3u' || route === 'groupM3u') {
    if (service.disableM3uOp && route === 'listM3u') {
      m3uLinks = pl;
      pl = scrapper + 'm3u?m3u=' + pl + '&query=m3u&page=' + numerPages;
    }

    page.appendItem("listM3u:" + m3uLinks + ':searchM3u:', "search", {
        title: "Buscar en M3U...",
    });
    page.appendItem('', 'separator', {
      title: '',
    });
  } else {  
    if (service.disableM3uOp) {
      if (theLastSearch !== title) {
        numerPages = 1;
      }

      pl = scrapper + 'm3u?m3u=' + m3uLinks + '&query=' + encodeURIComponent(title) + '&page=' + numerPages;

      theLastSearch = title;
    } else {
      pl = scrapper + 'm3u?m3u=' + theLastList + '&query=' + encodeURIComponent(title) + '&page=all';
    }
  }

  readAndParseM3U(page, pl);

  if (!m3uItems || m3uItems.length === 0) {
    page.error('No se encontraron resultados');
    return;
  }
  
  if (route === 'listM3u' || route === 'searchM3u') {
    showM3U(page, decodeURIComponent(pl));
  } else {
    for (var i in m3uItems) {
      if (decodeURIComponent(title) != m3uItems[i].group) {
        continue;
      }
      addItem(page, m3uItems[i].url, m3uItems[i].title, m3uItems[i].logo, m3uItems[i].duracion, m3uItems[i].sinopsis, '', '', '', '', '', '', '', '', '', '', '');
    }
  }

  if (service.disableM3uOp) {
    passPages(page, m3uItems.length, 'listM3u:' + m3uLinks + ':' + route + ':' + title, title);
  } else {
    page.metadata.title = new RichText(decodeURIComponent(title));
  }

  page.loading = false;
}

function passPages(page, num, redirect, title) {
  if (numerPages > 1) {
    page.options.createAction('gotoPageBackJson', 'Regresar Página', function() {
      numerPages--;
      page.redirect(redirect);
    });
  } 

  if (num === 100) {
    popup.notify("Puedes visitar la siguiente página, desde el menu lateral.  (Triangulo)" ,5);
    page.options.createAction('gotoPageNextJson', 'Siguiente Página', function() {
      numerPages++;
      page.redirect(redirect);
    });
  } else if (num < 100) {
    popup.notify("Resultados encontrados " + num, 5);
  } else if (num === 0) {
    page.error("No se encontraron resultados.");
  }

  page.metadata.title = new RichText((numerPages === 1 ? '' : 'Pag ' + numerPages + ' - ') + title);
}

// IPTV JSON

function mainIptv(page) {
  setPageHeader(page, 'Buscando Servidores...');
  page.model.contents = 'grid';

  var arg;
  if (!service.disableAdultos) {
    arg = 'General';
  } else {
    arg = 'Adultos';
  }  

  page.options.createAction('gotoInicio', 'Inicio', function() {
    page.redirect(plugin.id + ':start');
  });
  page.appendItem("iptvJson::", "search", {
      title: "Buscar canales...",
  });

  if (service.selectCountry == 'undefined') {
    popup.notify("Elige un Pais desde los Ajustes de Movian, baja a la Opcion", 7);
    popup.notify("Applications and Installed Plugins y Entra a PlayStr3am", 7);
  } 

  var url = scrapper + 'iptv?json=' + arg + '&query=' + service.selectCountry;
  if (jsonIptvUrl !== url || jsonIptvUrl === '') {
    var response;
    try {
        response = http.request(url, {
            headers: {
                'User-Agent': UA,
            },
        });
    } catch (err) {
        page.error('No se pudo obtener datos');
        page.loading = false;
        return;
    }
    jsonIptv = JSON.parse(response);
    jsonIptvUrl = url;
  }

  var secciones = jsonIptv['IPTV'];
  var seccion = Object.keys(secciones);

  for (var i = 0; i < seccion.length; i++) {
      var seccionTitle = seccion[i];
 
      page.appendItem('', 'separator', { title: '', });
      page.appendItem('', 'separator', {
        title: new RichText(coloredStr('<b>==★== <i>' + seccionTitle + '</i> ==★== </b>', orange)),
      });

      var canales = jsonIptv['IPTV'][seccionTitle];
      var canal = Object.keys(canales);

      var pos = 0;
      for (var j = 0; j < canal.length; j++) {
        var canalTitle = canal[j];
        var canalData = canales[canalTitle];
        var image = canalData.imagen ? canalData.imagen : Plugin.path + "images/iptv.png";

        if (pos < 4) {
          addItem(page, canalData.link, canalTitle, image, '', '', '', '', '', '', '', '', '', 'metadata', '', '', '');
        }
        
        if (pos === 4) {
          addItem(page, 'iptvJson:' + seccionTitle + ':', 'Mas de ' + seccionTitle, image, '', '', '', '', '', '', '', orange, '', '', '', '', '');
          break;
        }
        pos++;
      }
  }

  page.metadata.title = "IPTV";
  page.loading = false;
}

function showIptv(page, seccion, query) {
  if (query === '') {
    setPageHeader(page, 'IPTV - ' + seccion);

    var canales = jsonIptv['IPTV'][seccion];
    var canal = Object.keys(canales);

    for (var i = 0; i < canal.length; i++) {
      var canalTitle = canal[i];
      var canalData = canales[canalTitle];
      var image = canalData.imagen ? canalData.imagen : Plugin.path + "images/iptv.png";
      addItem(page, canalData.link, canalTitle, image, '', '', '', '', '', '', '', '', '', 'metadata', '', '', '');
    }
  } else {
    setPageHeader(page, 'IPTV - ' + query);
    page.model.contents = 'grid';
    
    var url = scrapper + 'iptv?json=Search&query=' + encodeURIComponent(query);
    if (jsonIptvSearchUrl !== url || jsonIptvSearchUrl === '') {
      var response;
      try {
          response = http.request(url, {
              headers: {
                  'User-Agent': UA,
              },
          });
      } catch (err) {
          page.error('No se pudo obtener datos');
          page.loading = false;
          return;
      }
      jsonIptvSearch = JSON.parse(response);
      jsonIptvSearchUrl = url;
    }

    var secciones = jsonIptvSearch[query];
    var seccion = Object.keys(secciones);

    for (var i = 0; i < seccion.length; i++) {
        var seccionTitle = seccion[i];
        var canales = jsonIptvSearch[query][seccionTitle];
        var canal = Object.keys(canales);

        for (var j = 0; j < canal.length; j++) {
          var canalTitle = canal[j];
          var canalData = canales[canalTitle];
          var image = canalData.imagen ? canalData.imagen : Plugin.path + "images/iptv.png";
          addItem(page, canalData.link, canalTitle, image, '', '', '', '', '', '', '', '', '' , 'metadata', '', '', '');
        }
    }

    addSearchToHistory(page, query, 'iptv');
  }
  page.model.contents = 'grid';
  page.loading = false;
}

// Descubrir JSON

function descubrirJson(page, seccion, cast) {
  var mode;
  if (service.eneableKids) {
    mode = 'Infantil';
  } else {
    mode = service.selectDescubrir;
  }

  var url, universal;
  if (cast != '') {
    setPageHeader(page, cast);
    universal = cast;
    url = scrapper + 'descubrir?query=Actores&seccion=' + encodeURIComponent(cast);
  } else {
    var arg = sloganCustom(page, seccion);
    setPageHeader(page, arg);
    if (theLastSearch !== seccion) {
      numerPages = 1;
    }
    universal = seccion;
    theLastSearch = seccion;
    url = scrapper + 'descubrir?query=' + mode + '&seccion=' + encodeURIComponent(seccion) + '&page=' + numerPages;
  }

  if (jsonDescubrirUrl !== url || jsonDescubrirUrl === '') {
    var response;
    try {
        response = http.request(url, {
            headers: {
                'User-Agent': UA,
            },
        });
    } catch (err) {
        page.error('No se pudo obtener datos');
        page.loading = false;
        return;
    }
    jsonDescubrir = JSON.parse(response);
    jsonDescubrirUrl = url;
  }

  if (cast != '') {
    var star = jsonDescubrir.items;

    var routePasive = 'descubrir:' + seccion + ':' + cast;
    var type = 'video';
    var icon = star.profile_path ? star.profile_path : Plugin.path + 'images/avatars.png';
    page.metadata.icon = icon;

    var collage = [{url: star.profile_path}];
    var background = star.backdrops ? star.backdrops : [];
    var backdrops = backdropsSorter(page, collage, background);

    var collage = [{url: star.profile_path}];
    var background = star.backdrops_path ? star.backdrops_path : [];
    var poster = star.poster_path ? star.poster_path : [];
    background = background.concat(poster);
    var backdrops = backdropsSorter(page, collage, background);

    var adult = '';
    if (star.adult === true) {
      adult = 'Si';
    } else if (star.adult === false) {
      adult = 'No';
    }

    var departament = departamentAsign(page, star.departament);

    page.appendPassiveItem(type, '', {
      title: new RichText(coloredStr('<b>' + cast + '</b>', blue)),
      icon: icon,
      genre: new RichText((star.gender ? coloredStr('<b>Sexo: </b>', blue) + star.gender + '\n' : '') +
        (adult ? coloredStr('<b>Contenido para Adultos: </b>', violet) + adult : '')),
      backdrops: backdrops,
      source: new RichText(coloredStr('<b>PlayStr3am</b>', violet)),
      tagline: new RichText((star.original_name ? coloredStr('<b>Nombre Real: </b>', orange) + star.original_name
        + '\n' : '') + (departament ? coloredStr('<b>Departamento: </b>', orange) + departament : '')),
      rating: star.raking,
      description: new RichText(coloredStr('<b>Participaciones Destacadas:</b>', orange) + '\n- ' +
        star.known_for[0] + '\n - ' + star.known_for[1] + '\n - ' + star.known_for[2]),
    });

    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Contenido Relacionado</i> ==★== </b>', violet))
    });
  }

  var canales = jsonDescubrir.items[universal];
  var canal = Object.keys(canales);

  var pos = 0;
  for (var i = 0; i < canal.length; i++) {
    var canalTitle = canal[i];
    var canalData = canales[canalTitle];
    if (service.selectDescubrir === 'Reparto' && cast === '') {
      var route = 'descubrir:' + seccion + ':' + canalTitle;
      var image = canalData.profile_path ? canalData.profile_path : Plugin.path + 'images/avatars.png';

      var collage = [{url: canalData.profile_path}];
      var background = canalData.backdrops_path ? canalData.backdrops_path : [];
      var poster = canalData.poster_path ? canalData.poster_path : [];
      background = background.concat(poster);
      var backdrops = backdropsSorter(page, collage, background);

      var adult = '';
      if (canalData.adult === true) {
        adult = 'Si';
      } else if (canalData.adult === false) {
        adult = 'No';
      }

      var item = addItem(page, route, canalTitle, image, '', adult, canalData.gender, canalData.original_name, canalData.departament, canalData.rating, canalData.known_for[0], orange, canalData.known_for[1], canalData.known_for[2], backdrops, '', '');
      addOptionForAddingToMyFavorites(item, route, canalTitle, image, '', canalData.adult, canalData.gender, canalData.original_name, canalData.departament, canalData.raking, '', backdrops, 'cast');
    } else {
      var id = canalData.id ? canalData.id : 'null';
      var route = 'jsonContent:' + canalTitle + ':' + id;
      var year = canalData.year ? canalData.year : '';
      var budget = canalData.budget ? canalData.budget : '';
      var image = canalData.still_path || Plugin.path + 'images/video.png';

      var genres = canalData.genres ? canalData.genres : [];
      var genresGlobal = controlArrays(page, genres);
      var similar = canalData.similar ? canalData.similar : [];
      var similarGlobal = controlArrays(page, similar);
      var castData = canalData.cast ? canalData.cast : [];
      var castInfo = canalData.castInfo ? canalData.castInfo : [];
      var castImage = canalData.castImage ? canalData.castImage : [];
      var collage = [{url: canalData.still_path}, {url: canalData.background}];

      var castGlobal = '';
      if (cast != '') {
        if (castData.length > 0) {
          for (var j = 0; j < castData.length; j++) {
            var castName = castData[j];
            if (castData[j].toLowerCase() === cast.toLowerCase()) {
              castGlobal = castName + ' como ' + castInfo[j] + '.';
              var castImageUrl = [{url: castImage[j]}];
              collage = collage.concat(castImageUrl);
            }
          }
        }
      } else {
        castGlobal = controlArrays(page, castData);
      }

      var backdrops = [];
      if (cast != '') {
        var vacio = [];
        backdrops = backdropsSorter(page, collage, vacio);
      } else {
        backdrops = backdropsSorter(page, collage, castImage);
      }

      var duration = '';
      if (canalData.media_type != 'tv') {
        duration = canalData.duration ? canalData.duration : '';
      }

      var item = addItem(page, route, canalTitle, image, duration, canalData.overview, genresGlobal, castGlobal, similarGlobal, canalData.rating, canalData.age_classification, orange, '', '', backdrops, year, budget);
      addOptionForAddingToMyFavorites(item, route, canalTitle, image, duration, canalData.overview, genresGlobal, castGlobal, similarGlobal, canalData.rating, canalData.age_classification, backdrops, 'json');
    }
    pos++;
  }

  if (cast === '') {
    passPages(page, pos, 'descubrir:' + seccion + ':', arg);
  } else {
    popup.notify('Contenido Relaciondo: ' + pos, 5);
  }
  page.loading = false;
}

// Peliculas JSON

function jsonParseSearch(page, query) {
  var header;
  if (numerPages === 1) {
    header = 'Buscando ' + query + '...';
  } else {
    header = 'Cambiando Página...';
  }
  setPageHeader(page, header);
  page.loading = true;
  var num = 0;

  if (theLastSearch !== query) {
    numerPages = 1;
  }

  var url = scrapper + 'peliculas?query=' + encodeURIComponent(query) + '&page=' + numerPages;
  if (dataSearchUrl !== url || dataSearchUrl === '') {
    var response;
    try {
      response = http.request(url, {
          headers: {
              'User-Agent': UA,
          },
      });
    } catch (err) {
      page.error("No se pudo obtener datos.");
      page.loading = false;
      return;
    }
    dataSearch = JSON.parse(response);
    dataSearchUrl = url;
  }

  for (var movieTitle in dataSearch.items) {
    if (dataSearch.items.hasOwnProperty(movieTitle)) {
      var movie = dataSearch.items[movieTitle];
      var image = movie.still_path || Plugin.path + 'images/video.png';
      var id = movie.id ? movie.id : 'null';
      var route = 'jsonContent:' + movieTitle + ':' + id;
      var year = movie.year ? movie.year : '';
      var budget = movie.budget ? movie.budget : '';

      var genres = movie.genres ? movie.genres : [];
      var genresGlobal = controlArrays(page, genres);
      var cast = movie.cast ? movie.cast : [];
      var castGlobal = controlArrays(page, cast);
      var similar = movie.similar ? movie.similar : [];
      var similarGlobal = controlArrays(page, similar);

      var collage = [{url: movie.still_path}, {url: movie.background}];
      var castImage = movie.castImage ? movie.castImage : [];
      var backdrops = backdropsSorter(page, collage, castImage);

      var duration = '';
      if (movie.media_type != 'tv') {
        duration = movie.duration;
      }

      var item = addItem(page, route, movieTitle, image, duration, movie.overview, genresGlobal, castGlobal, similarGlobal, movie.rating, movie.age_classification, orange, '', '', backdrops, year, budget);
      addOptionForAddingToMyFavorites(item, route, movieTitle, image, duration, movie.overview, genresGlobal, castGlobal, similarGlobal, movie.rating, movie.age_classification, backdrops, 'json');
      num++;
    }
    page.metadata.title = 'Agregando Items ' + num + ' de ' + Object.keys(dataSearch.items).length;
  }

  theLastSearch = query;
  if(numerPages === 1) {
    addSearchToHistory(page, query, 'movie');
  }

  passPages(page, num, 'searchJson:' + query, query);
  page.loading = false;
}

function jsonParseContent(page, title, id) {
  setPageHeader(page, 'Buscando Informacion: ' + title + '...');

  var url = scrapper + 'peliculas?query=' + encodeURIComponent(title) + '&id=' + id + '&page=JSON';
  if (dataUrl !== url || dataUrl === '') {
    var response;
    try {
      response = http.request(url, {
          headers: {
              'User-Agent': UA,
          },
      });
    } catch (err) {
      page.error("No se pudo obtener los datos.");
      page.loading = false;
      return;
    }
    data = JSON.parse(response);
    dataUrl = url;
  }
 
  var movie = data.items[title];
  if (!movie) {
    page.error("Película no encontrada.");
    page.loading = false;
    return;
  }

  var rating = movie.rating ? movie.rating : 0;
  var year = movie.year ? movie.year : '';
  var mediaType = movie.media_type ? movie.media_type : '';
  var age = movie.age_classification || '';
  var budget = movie.budget ? movie.budget : '';
  var sinopsis = movie.overview || "Sin descripción disponible.";
  var movieBackground = movie.background || Plugin.path + 'images/background.jpg';
  var image = movie.still_path || Plugin.path + 'images/video.png';
  var genres = movie.genres ? movie.genres : [];
  var cast = movie.cast ? movie.cast : [];
  var castInfo = movie.castInfo ? movie.castInfo : [];
  var similar = movie.similar ? movie.similar : [];
  var type = 'video';

  var duracion;
  if (mediaType === 'movie') {
    duracion = movie.duration ? movie.duration : '';
  } else {
    duracion = '';
  }

  var clasification = age_classification(page, age);

  background = movieBackground;
  page.metadata.icon = image;

  if (background != '') {
    page.metadata.background = background;
  }

  var premiumLinks = data.items[title];
  var links = premiumLinks.Links;
  var linkKeys = Object.keys(links);

  page.appendPassiveItem('video', "", {
    title: new RichText(coloredStr('<b>Sinopsis</b>', orange)),
    icon: image,
    genre: new RichText(coloredStr('<b>' + age + '</b>', orange) + clasification),
    rating: rating,
    source: new RichText(coloredStr('<b>PlayStr3am</b>', violet)),
    tagline: new RichText((duracion ? coloredStr('<b>Duracion: </b>', orange) + duracion + '\n' : '') +
             (budget ? coloredStr('<b>Presupuesto: </b>', orange) + budget : '')),
    description: new RichText((year ? coloredStr('<b>Año de Estreno: </b>', orange) + year + '\n' : '') +
             (sinopsis ? sinopsis : '')),
  });

  var servs;
  if (mediaType === 'movie') {
    servs = 'Servidores';
  } else if (mediaType === 'tv') {
    servs = 'Temporadas';
  }

  page.appendItem('', 'separator', {
    title: new RichText(coloredStr('<b>==★== <i>' + servs + '</i> ==★== </b>', orange)),
  });

  for (var i = 0; i < linkKeys.length; i++) {
    var linkName = linkKeys[i];
    var linkUrl = links[linkName];
    if (mediaType === 'movie' || mediaType === null) {
      addItem(page, linkUrl, linkName, image, duracion, '', '', '', '', '', '', '', '', 'metadata', '', '', '');
    } else if (mediaType === 'tv') {
      jsonSeasonData(page, linkUrl, id);
      break;
    }
  }

  if (genres.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Géneros</i> ==★== </b>', violet)),
    });
    for (var i = 0; i < genres.length; i++) {
      if (genres[i] != 'Desconocido') {
        var imageGenre = Plugin.path + 'images/genres/' + encodeURIComponent(genres[i]) + '.png';
        var backdropsGenre = [{url: imageGenre}]
        addItem(page, 'searchJson:' + genres[i], genres[i], imageGenre, '', '', '', '', '', '', '', violet, '', '', backdropsGenre, '', '');
      }
    }
  }

  if (cast.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Reparto</i> ==★== </b>', blue)),
    });

    for (var i = 0; i < cast.length; i++) {
      var castItem = cast[i];
      var route = 'descubrir:' + castItem.departament + ':' + castItem.name;
      var castImage = movie.castImage[i] ? movie.castImage[i] : Plugin.path + 'images/avatars.png';
      var castGender = castItem.gender ? castItem.gender : '';
      var castOriginal_name = castItem.original_name ? castItem.original_name : '';
      var castDepartament = castItem.departament ? castItem.departament : '';
      var castRating = castItem.rating ? castItem.rating : '';

      var knownFor = castItem.known_for && Array.isArray(castItem.known_for) ? castItem.known_for : [];
      var knownFor0 = knownFor.length > 0 ? knownFor[0] : '';
      var knownFor1 = knownFor.length > 1 ? knownFor[1] : '';
      var knownFor2 = knownFor.length > 2 ? knownFor[2] : '';

      var adult = '';
      if (castItem.adult === true) {
        adult = 'Si';
      } else if (castItem.adult === false) {
        adult = 'No';
      }

      var item = addItem(page, route, castItem.name, castImage, castInfo[i], adult, castGender, castOriginal_name, castDepartament, castRating, knownFor0, blue, knownFor1, knownFor2, '', '', '');
      addOptionForAddingToMyFavorites(item, route, castItem.name, castImage, castInfo[i], adult, castGender, castOriginal_name,  castDepartament, castRating, '', '', 'cast');
    }
  }

  if (similar.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Recomendado</i> ==★== </b>', green)),
    });

    var num = 0;
    for (var i = 0; i < similar.length; i++) {
      var similarItem = similar[i];
      var id = similarItem.id ? similarItem.id : 'null';
      var route = 'jsonContent:' + similarItem.name + ':' + id;
      var similarYear = similarItem.year ? similarItem.year : '';
      var similarBudget = similarItem.budget ? similarItem.budget : '';

      var similarImage = similarItem.still_path || Plugin.path + "images/video.png";
      var similarDuration = similarItem.duration ? similarItem.duration : '';
      var similarOverview = similarItem.overview ? similarItem.overview : '';
      var similarCastTest = similarItem.cast ? similarItem.cast : '';

      var similarGenres = similarItem.genres ? similarItem.genres : [];
      var similarGenresGlobal = controlArrays(page, similarGenres);
      var similarCast = similarItem.cast ? similarItem.cast : [];
      var similarCastGlobal = controlArrays(page, similarCast);

      if (similarDuration !== '' && similarCastTest !== '' && similarOverview !== '') {
        var item = addItem(page, route, similarItem.name, similarImage, similarDuration, similarOverview, similarGenresGlobal, similarCastGlobal, '', similarItem.rating, similarItem.age_classification, green, '', '', '', similarYear, similarBudget);
        addOptionForAddingToMyFavorites(item, route, similarItem.name, similarImage, similarDuration, similarOverview,  similarGenresGlobal, similarCastGlobal, '', similarItem.rating, similarItem.age_classification, '', 'json');
        num++;
      }
    }

    if (num === 0) {
      page.appendPassiveItem('directory', 'lo que sea', {
        title: new RichText(coloredStr('<b>Sin Similitudes encontradas en PlayStr3am</b>', red)),
        icon: Plugin.path + "images/video.png",
      });
    }

  }
  page.metadata.title = title;
  page.loading = false;
}

// Series JSON

function jsonSeasonData(page, pl, id) {
    page.metadata.title = "Cargando Temporadas...";

    var url = scrapper + 'series?query=' + pl + '&id=' + id;
    if (jsonDataUrl !== url || jsonDataUrl === '') {
      var response;
      try {
          response = http.request(url, {
              headers: {
                  'User-Agent': UA,
              },
          });
      } catch (err) {
          page.error("No se pudo obtener datos.");
          page.loading = false;
          return;
      }
      jsonData = JSON.parse(response);
      jsonDataUrl = url;
    }

    var seriesNames = jsonData.items;
    var seriesName = Object.keys(seriesNames);
    if (seriesName.length === 0) {
        page.error("No se encontraron series en el JSON.");
        page.loading = false;
        return;
    }

    var seasons = jsonData.items[seriesName];
    var temporadas = Object.keys(seasons);

    for (var i = 0; i < temporadas.length; i++) {
        var seasonTitle = temporadas[i];
        var seasonData = seasons[seasonTitle];
        if (seasonTitle === 'id') {  continue; } 
        var image = seasonData.image_path || Plugin.path + "images/video.png";
        var route = 'seasonsJson:' + seriesName + ':' + seasonTitle + ':';
        var episodesNumbers = Object.keys(jsonData.items[seriesName][seasonTitle]).length - 3;

        var episodes = jsonData.items[seriesName][seasonTitle];
        var episodeNames = Object.keys(episodes);

        var backdrops = [];
        for (var j = 0; j < episodeNames.length; j++) {
          var episodesTitle = episodeNames[j];
          if (episodesTitle === 'overview' || episodesTitle === 'image_path' || episodesTitle === 'rating') { continue; }
          var episodeData = episodes[episodesTitle];
          var imagesBackdrops = episodeData.image_path ? episodeData.image_path : '';
          if (imagesBackdrops !== '') {
            backdrops.push({url: episodeData.image_path});
          }
        }
        backdrops.push({url: logo});

        var item = addItem(page, route, seasonTitle, image, episodesNumbers + ' Episodios', seasonData.overview, '', '', '', seasonData.rating, '', orange, '', '', backdrops, '', '');
    }
    page.loading = false;
}

function jsonEpisodesData(page, seriesName, seasonTitle, episodeTitle) {
    if (episodeTitle === '') {
      setPageHeader(page, seasonTitle);
      if (background != '') {
        page.metadata.background = background;
      }

      if (!jsonData.items.hasOwnProperty(seriesName) || !jsonData.items[seriesName].hasOwnProperty(seasonTitle)) {
          page.error("No se encontraron episodios para " + seriesName + " - " + seasonTitle);
          page.loading = false;
          return;
      }
      
      var icon = jsonData.items[seriesName][seasonTitle].image_path;
      page.metadata.icon = icon;
      var episodes = jsonData.items[seriesName][seasonTitle];
      var episodeNumbers = Object.keys(episodes);

      for (var i = 0; i < episodeNumbers.length; i++) {
        var episodesTitle = episodeNumbers[i];
        if (episodesTitle === 'overview' || episodesTitle === 'image_path' || episodesTitle === 'rating') {  continue; }    
        var episodeData = episodes[episodesTitle];
        if (!episodeData) continue;
        if (!episodeData.hasOwnProperty('links')) {  continue; }
        var route = 'seasonsJson:' + seriesName + ':' + seasonTitle + ':' + episodesTitle;
        var image = episodeData.image_path || Plugin.path + "images/video.png";    
        var links = Object.keys(episodeData.links).length;

        var item = addItem(page, route, episodesTitle, image, episodeData.duration, episodeData.overview, '', '', '', episodeData.rating, '', orange, links, '', '', '', '');
      }
    } else {
      setPageHeader(page, episodeTitle);
      if (background != '') {
        page.metadata.background = background;
      }

      if (!jsonData.items.hasOwnProperty(seriesName) || !jsonData.items[seriesName].hasOwnProperty(seasonTitle) || !jsonData.items[seriesName][seasonTitle].hasOwnProperty(episodeTitle)) {
          page.error("No se encontraron enlaces para " + episodeTitle);
          page.loading = false;
          return;
      }

      var icon = jsonData.items[seriesName][seasonTitle][episodeTitle].imagen;
      page.metadata.icon = icon;
      var episodeData = jsonData['items'][seriesName][seasonTitle][episodeTitle];

      if (!episodeData.hasOwnProperty("links")) {
          page.error("Este episodio no tiene enlaces disponibles.");
          page.loading = false;
          return;
      }

      var links = episodeData.links;
      var linkKeys = Object.keys(links);

      for (var i = 0; i < linkKeys.length; i++) {
          var linkName = linkKeys[i];
          var linkUrl = links[linkName];

          addItem(page, linkUrl, linkName, episodeData.image_path, episodeData.duration, episodeData.overview, '', '', '', '', '', '', '', 'metadata', '', '', '');
      }
    }
    page.loading = false;
}

// Internet Archive

function addMediaItem(page, media) {
  var image = "https://archive.org/services/img/" + media.identifier;
  var route = "internetArchiveFiles:" + media.identifier + ':';
  var item = addItem(page, route, media.title, image, '', '', '', '', '', '', '', orange, '', '', '', '', '');
  addOptionForAddingToMyFavorites(item, route, media.title, image, '', '', '', '', '', '', '', '', 'archive');
  item.icon = image;
  page.entries++;
}

function addDiscoverSection(page) {
  var offset = 1;
  var count = 10;

  function loader() {
    if (!offset) return false;
    page.loading = true;

    var args = {
      q: 'mediatype:(movies OR audio)',
      fl: ["identifier", "title", "mediatype"],
      sort: ["downloads desc"],
      rows: count,
      page: offset,
      output: "json"
    };

    try {
      var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
        args: args
      }));
    } catch(err) {
      page.error('No se pudieron obtener datos de Internet Archive.');
      return;
    }

    if (offset == 1) {
      page.appendItem("", "separator", {
        title: ''
      });
    }

    page.loading = false;
    for (var i in c.response.docs) {
      var item = c.response.docs[i];
      if (item.mediatype === 'movies' || item.mediatype === 'audio') {
        addMediaItem(page, item);
        if (page.entries >= count) return offset = false;
      }
    }

    offset++;
    return c.response.docs && c.response.docs.length > 0;
  }
  loader();
  page.paginator = loader;
  page.loading = false;
}

function showFilesInterntArchive(page, id, query, count) {
  if (query === '') {
    setPageHeader(page, id);
    var encodedId = encodeURIComponent(id);
    var listingImage = "https://archive.org/services/img/" + encodedId;
    page.metadata.background = listingImage;
    var itemUrl = 'https://archive.org/metadata/' + encodedId;

    var response;
    try {
      response = http.request(itemUrl);
    } catch (err) {
      page.error("No se pudieron recuperar los metadatos del elemento.");
      page.loading = false;
      return;
    }

    var metadata = JSON.parse(response);
    if (!metadata || !metadata.files || metadata.files.length === 0) {
      page.error('No se han encontrado archivos en el elemento seleccionado.');
      page.loading = false;
      return;
    }

    var mediaFiles = metadata.files.filter(function(file) {
      return /\.(mp4|avi|3gp|mkv|mov|wmv|webm|flv|m4v|ts|mp3|ogg|m4a|wav|flac|aac|alac|wma)$/.test(file.name);
    });

    if (mediaFiles.length === 0) {
      page.error('No se han encontrado archivos en el elemento seleccionado.');
      page.loading = false;
      return;
    }

    var mediaType = /\.(mkv|mp4|avi|3gp|mkv|mov|wmv|webm|flv|m4v|ts)$/.test(file.name) ? 'metadata' : 'audio';
    mediaFiles.forEach(function(file) {
      var mediaUrl = 'https://archive.org/download/' + encodedId + '/' + encodeURIComponent(file.name);
      addItem(page, mediaUrl, file.name, listingImage, '', '', '', '', '', '', '', '', '', mediaType, '', '', '');
    });

    popup.notify("Algunos archivos pueden tener restricciones.", 5);
  } else if (id === '') {
    setPageHeader(page, "Buscando resultados para: " + query);
    page.model.contents = 'grid';
    var offset = 1;
    page.entries = 0;

    function loader() {
      if (!offset) return false;
      page.loading = true;

      var args = {
        q: query,
        fl: ["identifier", "title", "mediatype"],
        sort: ["downloads desc"],
        rows: count ? count : 50,
        page: offset,
        output: "json"
      };

      try {
        var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
          args: args
        }));
      } catch(err) {
        page.error('No se pudieron obtener datos de Internet Archive.');
        return;
      }

      page.loading = false;
      if (offset == 1 && page.metadata && c.response.numFound)
        page.metadata.title = query;
      page.model.contents = 'grid';
      for (var i in c.response.docs) {
        var item = c.response.docs[i];
        if (item.mediatype === 'movies' || item.mediatype === 'audio') {
          addMediaItem(page, item);
          if (count && page.entries >= count) return offset = false;
        }
      }
      offset++;
      return c.response.docs && c.response.docs.length > 0;
    }
    loader();
    page.paginator = loader;
    addSearchToHistory(page, query, 'archive');
  }

  page.loading = false;
}

function mainAndPopularInterntArchive(page, route) {
  if (route === "") {
    setPageHeader(page, "Internet Archive");

    page.options.createAction('gotoInicio', 'Inicio', function() {
      page.redirect(plugin.id + ':start');
    });
    page.appendItem("internetArchiveFiles::", 'search', {
      title: 'Busca en Archive.org'
    });
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Más Populares</i> ==★== </b>', orange)),
    });
  
    addDiscoverSection(page);
  
    page.options.createAction('gotoInternetArchive', 'Populares en Archive', function() {
      page.redirect(plugin.id + ':internetArchive:popular');
    });
   
    popup.notify("¡Visita Archive.org y dona si puedes!", 7);
  } else if (route === 'popular') {
    setPageHeader(page, "Populares en Archive");

    var args = {
      q: 'mediatype:movies',
      fl: ["identifier", "title", "mediatype"],
      sort: ["downloads desc"],
      rows: 100,
      output: "json"
    };

    try {
      var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
        args: args
      }));
    } catch(err) {
      page.error('No se pudieron obtener datos de Internet Archive.');
      return;
    }

    for (var i in c.response.docs) {
      var video = c.response.docs[i];
      if (video.mediatype === 'movies') {
        addMediaItem(page, video);
      }
    }
  }
  page.model.contents = 'grid';
  page.loading = false;
}

// Paginas Principales

new page.Route(plugin.id + ':start', function(page) {
  mainPage(page);
});

new page.Route(plugin.id + ':favoritesandRecord:(.*)', function(page, route) {
  favoriteAndPagesHistory(page, route);
});

// Paginas Internet Archive

new page.Route(plugin.id + ":internetArchive:(.*)", function(page, route) {
  mainAndPopularInterntArchive(page, route);
});

new page.Route("internetArchiveFiles:(.*):(.*)", function(page, id, query) {
  showFilesInterntArchive(page, id, query);
});

// Paginas M3U

new page.Route('listM3u:(.*):(.*):(.*)', function(page, pl, route, title) {
  pagesM3u(page, title, route, pl);
});

// Paginas JSON

new page.Route(plugin.id + ':iptv', function(page) {
  mainIptv(page);
});

new page.Route('iptvJson:(.*):(.*)', function(page, seccion, query) {
  showIptv(page, seccion, query);
});

new page.Route("descubrir:(.*):(.*)", function(page, seccion, cast) {
  descubrirJson(page, seccion, cast);
});

new page.Route('searchJson:(.*)', function(page, query) {
  jsonParseSearch(page, query);
});

new page.Route("jsonContent:(.*):(.*)", function (page, title, id) {
  jsonParseContent(page, title, id);
});

new page.Route('seasonsJson:(.*):(.*):(.*)', function(page, title, season, episode) {
  jsonEpisodesData(page, title, season, episode);
}); 